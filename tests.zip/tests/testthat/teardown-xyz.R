
#print(ls(envir = .GlobalEnv))
rm("x", envir = .GlobalEnv)
print(ls(envir = .GlobalEnv))