
assign("x", 2, envir = .GlobalEnv)
print(ls(envir = .GlobalEnv))