library(testthat)
library(SpiderSeqR)

test_check("SpiderSeqR")
